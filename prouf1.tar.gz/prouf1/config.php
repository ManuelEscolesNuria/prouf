<?php
    //Datos de conexion
    $dbhost="127.0.0.1";
    $dbname="project";
    $dbuser="manuel";
    $dbpass="linuxlinux";
    