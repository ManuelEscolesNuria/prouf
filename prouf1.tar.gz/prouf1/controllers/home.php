<?php

	require APP.'/src/render.php';
	$uname=$_SESSION['username'] ?? 'invitado';// ?? Sirve para esecificar que debe contener si no está creada
	echo render('home',['title'=>'Bienvenido/a '.$uname.' ¿que quieres hacer?']);
