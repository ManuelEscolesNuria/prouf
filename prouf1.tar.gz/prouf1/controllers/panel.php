<?php

	require APP.'/src/render.php';
	$uname=$_SESSION['username'] ?? 'invitado';
	echo render('panel',['title'=>'Bienvenido/a al panel de control '.$uname]);