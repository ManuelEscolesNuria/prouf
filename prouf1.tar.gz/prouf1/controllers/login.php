<?php

	require APP.'/src/render.php';
	$uname=$_SESSION['username'] ?? 'invitado';
	echo render('login',['title'=>'Inicia sesión']);