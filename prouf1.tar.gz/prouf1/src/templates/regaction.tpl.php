<?php

	include 'src/templates/header.tpl.php';

?>
	<main>
	<h1><?= $title; ?></h1>
    <h2>Ha habido un error al iniciar sesión</h2>
	</main>
	<form action="data.php" method ="POST">
		<div class="form-group">
			<label for="user">Usuario</label>
			<input type="text" class="form-control" id="user" placeholder="Escribe tu usuario"/>
		</div>
		<div class="form-group">
			<label for="passwd">Contraseña</label>
			<input type="password" class="form-control" id="passwd" placeholder="Contraseña">
		</div>
		<div class="form-check">
			<input type="checkbox" class="form-check-input" id="recordar">
			<label class="form-check-label" for="recordar">Recordarme</label>
		</div>
			<button type="submit" class="btn btn-primary">Iniciar</button>
	</form>
	
	<?php include 'src/templates/footer.tpl.php';?>