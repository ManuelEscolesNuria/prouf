<?php

  include 'src/templates/header.tpl.php';
	
?>
	<main><h1><?= $title; ?></h1></main>
	<br>
 
  <br>
  
  <a href='?url=login'><button class="btn btn-primary">Iniciar Sesión</button></a>
  <a href='?url=register'><button class="btn btn-primary">Registrarme</button></a>
  <a href='?url=panel'><button class="btn btn-primary">Panel de usuario</button></a>

<br>

<?php include 'src/templates/footer.tpl.php';?>
