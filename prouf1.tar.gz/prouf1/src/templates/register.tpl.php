<?php

	include 'src/templates/header.tpl.php';

?>
	<main>
	<h1><?= $title; ?></h1>
	</main>
	<form action="data.php" method ="POST">
		<div class="form-group">
			<label for="user">Usuario</label>
			<input type="text" class="form-control" id="user" placeholder="Escribe tu usuario"/>
		</div>
        <div class="form-group">
			<label for="email">Email</label>
			<input type="Email" class="form-control" id="email" placeholder="Escribe tu email">
		</div>
		<div class="form-group">
			<label for="passwd">Contraseña</label>
			<input type="password" class="form-control" id="passwd" placeholder="Contraseña">
		</div>

			<button type="submit" class="btn btn-primary">Registrarme</button>
	</form>
	
	<?php include 'src/templates/footer.tpl.php';?>