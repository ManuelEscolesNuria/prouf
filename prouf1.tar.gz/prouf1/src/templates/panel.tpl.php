<?php

	include 'src/templates/header.tpl.php';

?>
	<main>
	<h1><?= $title; ?></h1>
	</main>
	
    
	
	<?php include 'src/templates/footer.tpl.php';?>