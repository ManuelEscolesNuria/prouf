<?php

    function connectMysql(string $dbhost,string $dbname,string $userdb,string $dbpass){
        try{
            $db = new PDO("mysql:host=$dbhost; dbname=$dbname;", $userdb, $dbpass);

        }catch(PDOException $e){
            echo $e->getMessage();
            die;
        }
        return $db;
    }

    function Register($db, $name, $email ,$passwd){
        $sql="INSERT INTO Users(email,nombreu,passw)
        VALUES ('$email','$name','$passwd');";
        try{
            $db->exec($sql);
            $register = 1;
            return $rergister;
        }catch(PDOException $e){
            die($e->getMessage());
            $register = 0;
            return $rergister;
        }
    }

    function Login($db, $name, $passwd){
        $sql="SELECT nombreu,passw from Users where nombreu=:nombreu and passw=:passw";
        $stmt=$db->prepare($sql);
        $stmt->execute(['nombre'=>$name]);
        $stmt->execute(['passw'=>$passwd]);
        $data= $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }